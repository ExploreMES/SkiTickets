
# SnowSeason Starter (for TWA/APK)

This minimal site lets you put real files on **snowseason.app** so you can generate an Android APK/AAB with Bubblewrap (Trusted Web Activity).

## What’s inside
- `public/index.html` – simple welcome page
- `public/buy/index.html` – placeholder Buy page (your QR should point here)
- `public/manifest.webmanifest` – required web app manifest
- `public/sw.js` – minimal service worker
- `public/.well-known/assetlinks.json` – **placeholder** (replace the fingerprint!)
- `public/icons/icon-192.png` and `icon-512.png` – app icons

## How to deploy on GoDaddy (simplest path)

### Option A: Use GoDaddy cPanel / File Manager (Shared Hosting)
1. In GoDaddy, create a hosting plan (if you only see a "Welcome" parked page, you need hosting).
2. Open **cPanel** → **File Manager** → go to `public_html/` (this is your website root).
3. Upload the contents of the `public/` folder from this zip **into** `public_html/`.
   - That means `index.html` sits at `public_html/index.html`
   - Create folders `.well-known/`, `icons/`, and `buy/` inside `public_html/` and upload the files into them.
4. Visit `https://snowseason.app/` – you should see the starter page.
5. Visit `https://snowseason.app/manifest.webmanifest` – you should see JSON.
6. Visit `https://snowseason.app/.well-known/assetlinks.json` – you should see JSON.

### Option B: Use another host (Vercel/Netlify) and point GoDaddy DNS
1. Make a free account on Vercel.
2. Create a new **Project** and import this folder as a **Static Site**.
3. In Vercel, add the **Domain** `snowseason.app` to the project.
4. In GoDaddy → **DNS**, change the records to what Vercel asks (usually an `A` record for the apex and a `CNAME` for `www`), or change **Nameservers** to Vercel’s.
5. Once DNS updates, your site will show the starter.

## After it’s live
1. Install Node.js, Android Studio.
2. Run:
   ```bash
   npm i -g @bubblewrap/cli
   bubblewrap init --manifest=https://snowseason.app/manifest.webmanifest
   bubblewrap build
   ```
3. Get your keystore SHA-256 fingerprint and replace it in `public/.well-known/assetlinks.json` on your site.
4. Rebuild release:
   ```bash
   bubblewrap update
   bubblewrap build --release
   ```
5. Install `app-release-signed.apk` on your Android phone or upload the AAB to Play Console.

## Replace this placeholder
Edit `public/.well-known/assetlinks.json`:
- Replace the fingerprint string with your real SHA-256 certificate fingerprint from your Bubblewrap keystore.

